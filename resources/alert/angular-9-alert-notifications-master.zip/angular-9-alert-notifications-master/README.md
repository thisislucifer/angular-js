# angular-9-alert-notifications

Angular 9 - Alert Notifications

For a demo and further details see https://jasonwatmore.com/post/2020/04/30/angular-9-alert-notifications